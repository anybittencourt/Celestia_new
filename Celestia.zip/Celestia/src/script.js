const express = require('express');
const cors = require('cors');

const porta = 3002;
const app = express()

app.use(cors());
app.use(express.json());

app.listen(porta, () => console.log("Rodando na porta " + porta));

const connection = require('./db_config');
const upload = require('./multer');

// ROTAS DE CADASTRO DE USUÁRIOS

app.post('/cadastro/cadastrar', (request, response) => {
    let params = Array(
        request.body.nome,
        request.body.email,
        request.body.senha
    );
    let query = "INSERT INTO cadastro(nome, email, senha) VALUES(?,?,?);";
    connection.query(query, params, (err, results) => {
        if (results) {
            response
                .status(201)
                .json({
                    success: true,
                    menssage: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    menssage: "sem sucesso",
                    data: err
                })
        }
    })
});

app.get('/cadastro/listar', (request, response) => {
    const query = "SELECT * FROM cadastro";

    connection.query(query, (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});

app.put('/cadastro/editar/:id', (request, response) => {
    let params = [
        request.body.nome,  
        request.params.id    
    ];
    let query = "UPDATE cadastro SET nome = ? WHERE id_usuario = ?;";
    connection.query(query, params, (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao atualizar a senha",
                data: err
            });
        }
        response.status(200).json({
            success: true,
            message: "Senha atualizada com sucesso",
            data: results
        });
    });
});

app.delete('/cadastro/deletar/:id', (request, response) => {
    let id = request.params.id;

    let query = "DELETE FROM cadastro WHERE id_usuario = ?;"

    connection.query(query, [id], (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});

// ROTAS DE LOGIN

app.post('/login', (request, response) => {
    let params = Array(
        request.body.email
    )

    let query = "SELECT id,name,email,senha,perfil FROM cadastro WHERE email = ?";

    connection.query(query, params, (err, results) => {
        if (results.length > 0) {
            let senhaDigitada = request.body.senha
            let senhaBanco = results[0].senha

            if (senhaBanco == senhaDigitada) {
                response
                    .status(200)
                    .json({
                        success: true,
                        message: "Sucesso",
                        data: results[0]
                    })
            } else {
                response
                    .status(400)
                    .json({
                        success: false,
                        message: "Verifique sua senha!"
                    })
            }
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "E-mail não cadastrado!"
                })
        }
    })
})

// ROTAS DE CADASTRO DE PRODUTOS

app.post('/produtos/cadastrar', upload.single('file'), (request, response) => {
    let params = Array(
        request.body.nome,
        request.body.descricao,
        request.body.preco,
        request.file.filename
    );
    let query = "INSERT INTO produtos(nome, descricao, preco, imagem) VALUES(?,?,?,?);";
    connection.query(query, params, (err, results) => {
        if (results) {
            response
                .status(201)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    menssage: "sem sucesso",
                    data: err
                })
        }
    })
});

app.get('/produtos/listar', (request, response) => {
    const query = "SELECT * FROM produtos";

    connection.query(query, (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});

app.put('/produtos/editar/:id', (request, response) => {
    let params = Array(
        request.body.nome
    );
    let query = "UPTADE produtos SET nome = ?"

    connection.query(query, params, (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});

app.delete('/produtos/deletar/:id', (request, response) => {
    let id = request.params.id;

    let query = "DELETE FROM produtos WHERE id = ?;"

    connection.query(query, [id], (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});