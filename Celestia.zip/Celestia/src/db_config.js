// importar pacote do mysql
const mysql = require('mysql2');
// criar conexão com banco de dads
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'Celestia',
});
// testar a conexão
connection.connect((err) => {
    if (err) {
        throw err;
    } else {
        console.log('mysql conectado')
    }
});

module.exports = connection;