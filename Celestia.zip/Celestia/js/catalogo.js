// // // faz com que o produto adicionado vá para o banco de dados ao clicar em "adicionar ao catálogo"

async function catalogo(event) {
    event.preventDefault();
 
    const nome = document.getElementById('productName').value
    const descricao = document.getElementById('productDescription').value
    const preco = Number(document.getElementById('productPrice').value)
    const file = document.getElementById("file").files[0]

    let formData = new FormData();
 
    formData.append('productName', nome)
    formData.append('productDescription', descricao)
    formData.append('productPrice', preco)
    formData.append('file', file)
 
    const response = await fetch('http://localhost:3002/produtos/cadastrar', {
        method: "POST",
        body: formData
    })
 
    const results = await response.json();
 
    if (results.success) {
        alert(results.menssage)
    } else {
        alert(results.menssage)
    }
}
