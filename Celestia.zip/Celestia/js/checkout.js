// Voltar ao index.html
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('backArrow').addEventListener('click', function () {
        window.location.href = 'index.html';
    });

    document.getElementById('calculateShipping').addEventListener('click', function () {
    });

    document.getElementById('finalizePurchase').addEventListener('click', function () {
        document.getElementById('modal').style.display = 'block';
    });

    document.querySelector('.close').addEventListener('click', function () {
        document.getElementById('modal').style.display = 'none';
    });

    document.getElementById('closeModal').addEventListener('click', function () {
        document.getElementById('modal').style.display = 'none';
    });
});
