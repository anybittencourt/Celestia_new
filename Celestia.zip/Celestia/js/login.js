// botão de entrar (login)
function entrar(event) {
    event.preventDefault(); 
    document.getElementById('login-modal').classList.remove('hidden'); // Exibe o modal de login
}

function fecharModal(event) {
    if (event) {
        if (event.target.id === 'login-modal' || event.target.id === 'closeLoginBtn') {
            document.getElementById('login-modal').classList.add('hidden'); // Oculta o modal de login
        }
    } else {
        document.getElementById('login-modal').classList.add('hidden'); // Oculta o modal de login
    }
}

function fecharModalCadastro() {
    document.getElementById('registration-form-container').classList.add('hidden'); 
    document.getElementById('overlay').classList.add('hidden');
}

function alternarParaLogin() {
    fecharModalCadastro(); // Fecha o modal de cadastro
    document.getElementById('login-modal').classList.remove('hidden'); 
}

function submitLogin() {
    // Lógica para login
    alert('Login realizado!');
    fecharModal();
}

function cadastrar(event) {
    event.preventDefault(); 
    alert('Cadastro realizado!');
}

// Faz com que os usuários logados vá para o banco de dados ao clicar em "cadastrar"

async function entrar(event) {
    event.preventDefault();
 
    const email = document.getElementById('email_login').value;
    const senha = document.getElementById('senha_login').value;
 
    const data = {email, senha};
    // console.log(data)

    const response = await fetch("http://localhost:3002/login", {
        method: "POST",
        headers: {
            "Content-Type":"application/json"
        },
        body: JSON.stringify(data)
    })

    let results = await response.json();
    
    if (results.success) {
        let userData = results.data;

        localStorage.setItem('informacoes', JSON.stringify(userData))

        let html = document.getElementById('informacoes')
        let dados = JSON.parse(localStorage.getItem('informacoes'))
        console.log(dados)

        html.innerHTML = `<div style = "display: flex flex-direction: column; align-items: end">
                        Perfil: ${dados.perfil}
                        </div>`
                        
        html.style.display = 'block'

        alert(results.message)

    } else{
        alert(results.message)
    }
}

// logout
function sair() {
    localStorage.removeItem('informacoes')
    window.location.href = "index.html"
}


