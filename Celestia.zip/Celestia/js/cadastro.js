// Abrir modal de cadastro de usuário

document.addEventListener('DOMContentLoaded', (event) => {
    const openModalBtn = document.getElementById('openModalBtn');
    const overlay = document.getElementById('overlay');
    const modal = document.getElementById('registration-form-container');
    const closeBtn = document.getElementById('closeBtn');

    openModalBtn.addEventListener('click', () => {
        overlay.classList.remove('hidden');
        modal.classList.remove('hidden');
    });

    overlay.addEventListener('click', () => {
        overlay.classList.add('hidden');
        modal.classList.add('hidden');
    });

    closeBtn.addEventListener('click', () => {
        overlay.classList.add('hidden');
        modal.classList.add('hidden');
    });
});

// Faz com que os usuários cadastrados vá para o banco de dados ao clicar em "cadastrar"

async function cadastroUsuario(event) {
    event.preventDefault();
 
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
 
    const data = {nome, email, senha };
    console.log(data)
    const response = await fetch('http://localhost:3002/cadastro/cadastrar', {
        method: "POST",
        headers: {
            "Content-Type":"application/json"
        },
        body: JSON.stringify(data)
    })
 
    const results = await response.json();
 
    if (results.success) {
        localStorage.setItem('Informacoes', JSON.stringify(results.data))
        console.log(results.menssage)
    } else {
        console.log(alert.menssage)
    }
}
